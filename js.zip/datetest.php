<?php
echo date('Y-m-d H:i:s', (time()-25200))."<br/>".date('Y-m-d H:i:s');
?>